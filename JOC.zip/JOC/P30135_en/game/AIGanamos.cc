#include "Player.hh"


/**
 * Write the name of your player and save this file
 * with the same name and .cc extension.
 */
#define PLAYER_NAME Ganamos_v2


struct PLAYER_NAME : public Player {

  /**
   * Factory: returns a new instance of this class.
   * Do not modify this function.
   */
  static Player* factory () {
    return new PLAYER_NAME;
  }

  /**
   * Types and attributes for your player can be defined here.
   */
  typedef  vector<char> Row;
  typedef  vector<Row> Matrix;

  typedef vector<bool> Rowb;
  typedef vector<Rowb> Matrixb;

  Matrix M;
  Matrixb B;
  Matrix aux;
  vector<int> pos_x = {1, -1, 0, 0};
  vector<int> pos_y = {0, 0, 1, -1};

  int queen_id = -1;
  int worker_id = -1;
  int soldier_id = -1;
  int n_soldier;
  int n_worker;

  // Return a Matrix with the position of all the ants and bonus
  Matrix map(){
    vector<int> my_queen_ids = queens(me());
    if (not my_queen_ids.empty()) {
      queen_id = my_queen_ids[0];
    }
    Matrix N(board_rows(), Row(board_cols()));
    
    for (int i = 0; i < board_rows(); ++i) {
      for (int j = 0; j < board_cols(); ++j) {
        
        if (cell(i, j).id != -1){

          Ant a = ant(cell(i,j).id);

          if (cell(i, j).id == queen_id) N[i][j] = 'Q';
                  
          else if (a.player == me() and a.type == Worker) N[i][j] = 'T';

          else if (a.player == me() and a.type == Soldier) N[i][j] = 'Z';

          else if (a.type == Worker) N[i][j] = 'W'; 
        
          else if (a.type == Soldier) N[i][j] = 'S';

          else if (a.type == Queen) N[i][j] = 'U';
          
        }

        else if(cell(i,j).bonus != None) N[i][j] = 'p';

        else if(cell(i,j).type == Soil) N[i][j] = '.';

        else if(cell(i,j).type == Water) N[i][j] = 'X';
      }
      
    }
    return N;
  }

  Matrixb food(){
    Matrixb N(board_rows(), Rowb(board_cols(), false));
    return N;
  }

  bool pos_ok_sol(int i, int j){
    return pos_ok(i,j) and (M[i][j] != 'T' and M[i][j] != 'Z' and M[i][j] != 'X' and M[i][j] != 'Q' and M[i][j] != 'U'); 
  }

  bool pos_ok_queen(int i, int j){
    return pos_ok(i,j) and (M[i][j] != 'T' and M[i][j] != 'Z' and M[i][j] != 'X' and M[i][j] != 'U'); 
  }

  bool pos_ok_work(int x, int y){
    return pos_ok(x,y) and (M[x][y] != 'T' and M[x][y] != 'Z' and M[x][y] != 'X' and M[x][y] != 'Q' and M[x][y] != 'W' and M[x][y] != 'S' and M[x][y] != 'U');
  }

  bool create_sol(Ant queen){
    return queen.reserve[0] >= soldier_carbo() and queen.reserve[1] >= soldier_prote() and queen.reserve[2] >= soldier_lipid();
  }

  bool create_wor(Ant queen){
    return queen.reserve[0] >= worker_carbo() and queen.reserve[1] >= worker_prote() and queen.reserve[2] >= worker_lipid();
  }

  int bfs_soldier(int x0, int y0, char busqueda){

    aux = M;
    vector<vector<int>> dist(aux.size(), vector<int>(aux[0].size(), 0));
    queue<pair<int,int>> q;
    
    q.push({x0,y0});
    

    while(not q.empty()){

      int x = q.front().first;
      int y = q.front().second;
      q.pop();

      if(pos_ok(x, y)){

        if(aux[x][y] == busqueda) return dist[x][y];
        if(aux[x][y] != 'X'){

          aux[x][y] = 'X';
          
          for(int i = 0; i < 4; ++i){
            int xp = x + pos_x[i];
            int yp = y + pos_y[i];

            if(pos_ok(xp, yp)){

              q.push({xp, yp});
              dist[xp][yp] = dist[x][y] + 1;
            }
          }
        }
      }
    }
    return -1;
  }

  int bfs_worker(int x0, int y0, char busqueda){

    aux = M;
    vector<vector<int>> dist(aux.size(), vector<int>(aux[0].size(), 0));
    queue<pair<int,int>> q;
    
    q.push({x0,y0});
    

    while(not q.empty()){

      int x = q.front().first;
      int y = q.front().second;
      q.pop();

      if(pos_ok(x, y)){

        if(aux[x][y] == busqueda and B[x][y] == false) return dist[x][y];
        if(aux[x][y] != 'X'){

          aux[x][y] = 'X';
          
          for(int i = 0; i < 4; ++i){
            int xp = x + pos_x[i];
            int yp = y + pos_y[i];

            if(pos_ok(xp, yp)){

              q.push({xp, yp});
              dist[xp][yp] = dist[x][y] + 1;
            }
          }
        }
      }
    }
    return -1;
  }

  int bfs_queen(int x0, int y0, char busqueda){

    aux = M;
    vector<vector<int>> dist(aux.size(), vector<int>(aux[0].size(), 0));
    queue<pair<int,int>> q;
    
    q.push({x0,y0});
    

    while(not q.empty()){

      int x = q.front().first;
      int y = q.front().second;
      q.pop();

      if(pos_ok(x, y)){

        if(aux[x][y] == busqueda) return dist[x][y];
        if(aux[x][y] != 'X'){

          aux[x][y] = 'X';
          
          for(int i = 0; i < 4; ++i){
            int xp = x + pos_x[i];
            int yp = y + pos_y[i];

            if(pos_ok(xp, yp)){

              q.push({xp, yp});
              dist[xp][yp] = dist[x][y] + 1;
            }
          }
        }
      }
    }
    return -1;
  }

  void move_sol(){
    vector<int> my_soldiers_ids = soldiers(me());
    n_soldier = my_soldiers_ids.size();
      
    for (int i =0; i < n_soldier; i++) {
      soldier_id = my_soldiers_ids[i];
      Ant soldier = ant(soldier_id);
        
      int d;
      int x = soldier.pos.i;
      int y = soldier.pos.j;
      //run away if there is any soldier enemy or queen ant around
      
      d = bfs_soldier(x, y, 'U');
      if(d<=2){
      
        if(pos_ok_sol(x+1, y) and bfs_soldier(x+1, y, 'U') >=d){
          M[x+1][y] = 'X';
          move(soldier_id, Down);
        }

        else if(pos_ok_sol(x-1, y) and bfs_soldier(x-1, y, 'U') >=d){
          M[x-1][y] = 'X';
          move(soldier_id, Up);
        }

        else if(pos_ok_sol(x, y+1) and bfs_soldier(x, y+1, 'U') >=d){
          M[x][y+1] = 'X';
          move(soldier_id, Right);
        }

        else if(pos_ok_sol(x, y-1) and bfs_soldier(x, y-1, 'U') >=d){
          M[x][y-1] = 'X';
          move(soldier_id, Left);
        }
      }

      d = bfs_soldier(x, y, 'S');
      if(d<=2){
        if(pos_ok_sol(x+1, y) and bfs_soldier(x+1, y, 'S') <d){
          M[x+1][y] = 'X';
          move(soldier_id, Down);
        }

        else if(pos_ok_sol(x-1, y) and bfs_soldier(x-1, y, 'S') <d){
          M[x-1][y] = 'X';
          move(soldier_id, Up);
        }

        else if(pos_ok_sol(x, y+1) and bfs_soldier(x, y+1, 'S') <d){
          M[x][y+1] = 'X';
          move(soldier_id, Right);
        }

        else if(pos_ok_sol(x, y-1) and bfs_soldier(x, y-1, 'S') <d){
          M[x][y-1] = 'X';
          move(soldier_id, Left);
        }
      }

      d = bfs_soldier(x, y, 'W');

      if(pos_ok_sol(x+1, y) and bfs_soldier(x+1, y, 'W') <d){
        M[x+1][y] = 'X';
        move(soldier_id, Down);
      }

      else if(pos_ok_sol(x-1, y) and bfs_soldier(x-1, y, 'W') <d){
        M[x-1][y] = 'X';
        move(soldier_id, Up);
      }

      else if(pos_ok_sol(x, y+1) and bfs_soldier(x, y+1, 'W') <d){
        M[x][y+1] = 'X';
        move(soldier_id, Right);
      }

      else if(pos_ok_sol(x, y-1) and bfs_soldier(x, y-1, 'W') <d){
        M[x][y-1] = 'X';
        move(soldier_id, Left);
      }
    }    
  }

  void move_queen(){
    vector<int> my_queen_ids = queens(me());
    int n = my_queen_ids.size();
    if (not my_queen_ids.empty()) {
      if(queen_id != my_queen_ids[0]) B = food();

      queen_id = my_queen_ids[0];
      Ant queen = ant(queen_id);
        
      int d;
      int x = queen.pos.i;
      int y = queen.pos.j;
      
      d= bfs_queen(x, y, 'S');

      if(d == 1){
        if(pos_ok_queen(x+1, y) and bfs_queen(x+1, y, 'S') <=d){
          M[x+1][y] = 'X';
          move(queen_id, Down);
        }

        else if(pos_ok_queen(x-1, y) and bfs_queen(x-1, y, 'S') <=d){
          M[x-1][y] = 'X';
          move(queen_id, Up);
        }

        else if(pos_ok_queen(x, y+1) and bfs_queen(x, y+1, 'S') <=d){
          M[x][y+1] = 'X';
          move(queen_id, Right);
        }

        else if(pos_ok_queen(x, y-1) and bfs_queen(x, y-1, 'S') <=d){
          M[x][y-1] = 'X';
          move(queen_id, Left);
        }
      }

      else if(n_soldier <= 3 and n_worker > 2){
        if(create_sol(queen)){
          if(M[x+1][y] == '.') lay(queen_id, Down, Soldier);

          else if(M[x][y-1] == '.') lay(queen_id, Left, Soldier);
        
          else if(M[x][y+1] == '.') lay(queen_id, Right, Soldier);
        
          else if(M[x-1][y] == '.') lay(queen_id, Up, Soldier);
        }  
      }

      else if(n_worker <= 4 and create_wor(queen)){
        if(M[x+1][y] == '.') lay(queen_id, Down, Worker);
        
        else if(M[x][y-1] == '.') lay(queen_id, Left, Worker);
        
        else if(M[x][y+1] == '.') lay(queen_id, Right, Worker);
        
        else if(M[x-1][y] == '.') lay(queen_id, Up, Worker);
      }

      d = bfs_queen(x, y, 'p');

      if(pos_ok_queen(x+1, y) and bfs_queen(x+1, y, 'p') <d){
        M[x+1][y] = 'X';
        B[x+1][y] = false;
        move(queen_id, Down);
      }

      else if(pos_ok_queen(x-1, y) and bfs_queen(x-1, y, 'p') <d){
        M[x-1][y] = 'X';
        B[x-1][y] = false;
        move(queen_id, Up);
      }

      else if(pos_ok_queen(x, y+1) and bfs_queen(x, y+1, 'p') <d){
        M[x][y+1] = 'X';
        B[x][y+1] = false;
        move(queen_id, Right);
      }

      else if(pos_ok_queen(x, y-1) and bfs_queen(x, y-1, 'p') <d){
        M[x][y-1] = 'X';
        B[x][y-1] = false;
        move(queen_id, Left);
      }
    }    
  }


  void move_worker(){
    vector<int> my_workers_ids = workers(me());
    n_worker = my_workers_ids.size();
      
    for (int i =0; i < n_worker; i++) {
      worker_id = my_workers_ids[i];
      Ant worker = ant(worker_id);
      //Nutrients on the floor?
      Pos p = worker.pos;
      Cell ce = cell(p);
      int x = worker.pos.i;
      int y = worker.pos.j;
      if (ce.bonus != None and worker.bonus == None and B[x][y] == false) take(worker_id);
      
      int d;
      bool run_away = false;

      //run away if there is any enemy ant around
      d = bfs_worker(x, y, 'S');
      if(d <= 2) run_away = true;

      d = bfs_worker(x, y, 'U');
      if(d <= 2) run_away = true;

      if(run_away == true){
        if(pos_ok_work(x+1, y) and bfs_worker(x+1, y, 'U') >=d and bfs_worker(x+1, y, 'S') >= d){
          M[x+1][y] = 'X';
          move(worker_id, Down);
        }

        else if(pos_ok_work(x-1, y) and bfs_worker(x-1, y, 'U') >=d and bfs_worker(x-1, y, 'S') >= d){
          M[x-1][y] = 'X';
          move(worker_id, Up);
        }

        else if(pos_ok_work(x, y+1) and bfs_worker(x, y+1, 'U') >=d and bfs_worker(x, y+1, 'S') >= d){
          M[x][y+1] = 'X';
          move(worker_id, Right);
        }

        else if(pos_ok_work(x, y-1) and bfs_worker(x, y-1, 'U') >=d and bfs_worker(x, y-1, 'S') >= d){
          M[x][y-1] = 'X';
          move(worker_id, Left);
        }
      }

      d = bfs_worker(x, y, 'Q'); 
      if(d<=2 and worker.bonus != None and ce.bonus == None){
        B[x][y] = true;
        leave(worker_id);
      }

      //Go to my queen to feed her
      d = bfs_worker(x, y, 'Q');
      if(worker.bonus != None and d > 1){
        
        if(pos_ok_work(x+1, y) and bfs_worker(x+1, y, 'Q') < d){
          M[x+1][y] = 'X';
          move(worker_id, Down);
        }

        else if(pos_ok_work(x-1, y) and bfs_worker(x-1, y, 'Q') < d){
          M[x-1][y] = 'X';
          move(worker_id, Up);
        }
        
        else if(pos_ok_work(x, y-1) and bfs_worker(x, y-1, 'Q') < d){
          M[x][y-1] = 'X';
          move(worker_id, Left);
        }

        else if(pos_ok_work(x, y+1) and bfs_worker(x, y+1, 'Q') < d){
          M[x][y+1] = 'X';
          move(worker_id, Right);
        }
      }
       
      d = bfs_worker(x, y, 'p');
      
      if(pos_ok_work(x+1, y) and bfs_worker(x+1, y, 'p') <= d){
          M[x+1][y] = 'X';
          move(worker_id, Down);
      }

      else if(pos_ok_work(x-1, y) and bfs_worker(x-1, y, 'p') <= d){
          M[x-1][y] = 'X';
          move(worker_id, Up);
      }
  
      else if(pos_ok_work(x, y-1) and bfs_worker(x, y-1, 'p') <= d){
          M[x][y-1] = 'X';
          move(worker_id, Left);
      }

      else if(pos_ok_work(x, y+1) and bfs_worker(x, y+1, 'p') <= d){
          M[x][y+1] = 'X';
          move(worker_id, Right);
      } 
    }   
  }



  /**
   * Play method, invoked once per each round.
   */
  virtual void play () {
    if(round()==0) B = food();
    M = map();
    // If nearly out of time, do nothing.
    double st = status(me());
    if (st >= 0.9) return;
    
    //Soldier
    move_sol();

    //Worker
    move_worker();
    
    //Queen
    move_queen();
  }
};


/**
 * Do not modify the following line.
 */
RegisterPlayer(PLAYER_NAME);

