bool secure_up(int i, int j){
  bool sec = false;
  if(pos_ok (i, j)){
    Cell c = cell(i, j);
    if(c.id == -1 and c.type != Water){
      sec = true;
      if(pos_ok(i-1, j)){
        c = cell(i-1, j);
        if (c.id != -1) sec = false;
      }
      if(pos_ok(i, j-1)){
        c = cell(i, j-1);
        if (c.id != -1) sec = false;
      }
      if(pos_ok(i, j+1)){
        c = cell(i, j+1);
        if (c.id != -1) sec = false;
      }
    }
  }
  return sec;
}

bool secure_right(int i, int j){
  bool sec = false;
  if(pos_ok (i, j)){
    Cell c = cell(i, j);
    if(c.id == -1 and c.type != Water){
      sec = true;
      if(pos_ok(i-1, j)){
        c = cell(i-1, j);
        if (c.id != -1) sec = false;
      }
      if(pos_ok(i+1, j)){
        c = cell(i+1, j);
        if (c.id != -1) sec = false;
      }
      if(pos_ok(i, j+1)){
        c = cell(i, j+1);
        if (c.id != -1) sec = false;
      }
    }
  }
  return sec;
}

bool secure_down(int i, int j){
  bool sec = false;
  if(pos_ok (i, j)){
    Cell c = cell(i, j);
    if(c.id == -1 and c.type != Water){
      sec = true;
      if(pos_ok(i+1, j)){
        c = cell(i+1, j);
        if (c.id != -1) sec = false;
      }
      if(pos_ok(i, j-1)){
        c = cell(i, j-1);
        if (c.id != -1) sec = false;
      }
      if(pos_ok(i, j+1)){
        c = cell(i, j+1);
        if (c.id != -1) sec = false;
      }
    }
  }
  return sec;
}

bool secure_left(int i, int j){
  bool sec = false;
  if(pos_ok (i, j)){
    Cell c = cell(i, j);
    if(c.id == -1 and c.type != Water){
      sec = true;
      if(pos_ok(i-1, j)){
        c = cell(i-1, j);
        if (c.id != -1) sec = false;
      }
      if(pos_ok(i, j-1)){
        c = cell(i, j);
        if (c.id != -1) sec = false;
      }
      if(pos_ok(i+1, j)){
        c = cell(i+1, j);
        if (c.id != -1) sec = false;
      }
    }
  }
  return sec;
}


/**
 * Search values: q = queen, b = bread, l = leaf, s = seed
 * Return the direction (if exists), else return 'n'
 */

char path_worker(int x, int y, char search){
  return 'c';
}



bool prioridad(int i, int j){
  for(int x = i-1; i <= i+1; i++){
    for (int y = y-1; y <= y+1; y++){
      if (pos_ok(x, y) and M[x][y] == 'W'); 
    }
  }
}


bool prof(int x, int y, char busqueda, char block){
    if(not pos_ok(i, j)) return false;
    if(aux[x][y] == 'X' or aux[x][y] == 'Q' or aux[x][y] == 'W' or aux[x][y] == 'S' or aux[x][y] == 'U')return false;
    if(aux[x][y] == busqueda) return true;
    aux[x][y] = 'X';
    if(block == 'u') return prof(x+1, y, busqueda, block) or prof(x, y+1, busqueda, block) or prof(x, y-1, busqueda, block);
    else if (block == 'd')return prof(x-1, y, busqueda, block) or prof(x, y+1, busqueda, block) or prof(x, y-1, busqueda, block);
    else if(block == 'r')return prof(x-1, y, busqueda, block) or prof(x+1, y, busqueda, block) or prof(x, y-1, busqueda, block);
    else return prof(x-1, y, busqueda, block) or prof(x+1, y, busqueda, block) or prof(x, y+1, busqueda, block);
}

char search(int i, int j, char busqueda){
  char c = 'n';
  aux = M;
  if(prof(i, j, busqueda, 'u')){
    if(pos_ok_work(i, j, 'r') and prof(i, j+1, busqueda, 'l')) c = 'r';
    else if(pos_ok_work(i, j, 'l') and prof(i, j-1, busqueda, 'r')) c = 'l';
    else c= 'd';   
  }
  aux = M;
  if(prof(i, j, busqueda, 'd')){
    if(pos_ok_work(i, j, 'r') and prof(i, j+1, busqueda, 'l')) c = 'r';
    else if(pos_ok_work(i, j, 'l') and prof(i, j-1, busqueda, 'r')) c = 'l';
    else c = 'u';   
  }
  return c;
}

vector<int> food (){
  vector<int> my_workers_ids = workers(me());
  n = my_workers_ids.size();
  vector<int> v{0,0,0};
  for (int i =0; i < n; i++){
    worker_id = my_workers_ids[i];
    Ant worker = ant(worker_id);
    if(worker.bonus == Seed){
      v[1]++;
      v[2]+=2;
    }
    else if (worker.bonus == Bread){
      v[0]+=2;
      v[2]++;
    }
    else if(worker.bonus == Leaf){
      v[0]++;
      v[1]+=2;
    }
  }
  return v;
}




  bool prof(int x, int y, char busqueda, char block){
      if(not pos_ok(x, y)) return false;
      if(aux[x][y] == 'X' or aux[x][y] == 'Q' or aux[x][y] == 'W' or aux[x][y] == 'S' or aux[x][y] == 'U')return false;
      if(aux[x][y] == busqueda) return true;
      aux[x][y] = 'X';
      if(block == 'u') return prof(x+1, y, busqueda, block) or prof(x, y+1, busqueda, block) or prof(x, y-1, busqueda, block);
      else if (block == 'd')return prof(x-1, y, busqueda, block) or prof(x, y+1, busqueda, block) or prof(x, y-1, busqueda, block);
      else if(block == 'r')return prof(x-1, y, busqueda, block) or prof(x+1, y, busqueda, block) or prof(x, y-1, busqueda, block);
      else return prof(x-1, y, busqueda, block) or prof(x+1, y, busqueda, block) or prof(x, y+1, busqueda, block);
  }
  char search(int i, int j, char busqueda){
    char c = 'n';
    aux = M;
    if(prof(i, j, busqueda, 'u')){
      if(pos_ok_work(i, j, 'r') and prof(i, j+1, busqueda, 'l')) c = 'r';
      else if(pos_ok_work(i, j, 'l') and prof(i, j-1, busqueda, 'r')) c = 'l';
      else c= 'd';   
    }
    aux = M;
    if(prof(i, j, busqueda, 'd')){
      if(pos_ok_work(i, j, 'r') and prof(i, j+1, busqueda, 'l')) c = 'r';
      else if(pos_ok_work(i, j, 'l') and prof(i, j-1, busqueda, 'r')) c = 'l';
      else c = 'u';   
    }
    return c;
  }


  bool pos_ok_work(int x, int y, char c){
    if (c == 'l') return pos_ok(x ,y-1) and (M[x][y-1] != 'X' and M[x][y-1] != 'Q' and M[x][y-1] != 'W' and M[x][y-1] != 'S' and M[x][y-1] != 'U');
    else if(c == 'r') return pos_ok(x,y+1) and (M[x][y+1] != 'X' and M[x][y+1] != 'Q' and M[x][y+1] != 'W' and M[x][y+1] != 'S' and M[x][y+1] != 'U');
    else if(c == 'u') return pos_ok(x-1,y) and (M[x-1][y] != 'X' and M[x-1][y] != 'Q' and M[x-1][y] != 'W' and M[x-1][y] != 'S' and M[x-1][y] != 'U');
    else return pos_ok(x+1,y) and (M[x+1][y] != 'X' and M[x+1][y] != 'Q' and M[x+1][y] != 'W' and M[x+1][y] != 'S' and M[x+1][y] != 'U'); 
  }
  
  modificar
  char move_sec_wor(int i, int j){    
    char c = 'n';
  
    
      if(pos_ok_work(i, j, 'r')){
        M[i][j+1] = 'X';
        c = 'r';
      }
      else if(pos_ok_work(i, j, 'l')){
        M[i][j-1] = 'X';
        c = 'l';
      }
      else if(pos_ok_work(i, j, 'd')){
        M[i+1][j] = 'X';
        c = 'd';
      }
      else if(pos_ok_work(i, j, 'u')){
        M[i-1][j] = 'X';
        c = 'u';
      }
    
    return c;
  }
  